def say_hello():
    """Returns a friendly greeting."""
    return "Hello, World from my_package!"