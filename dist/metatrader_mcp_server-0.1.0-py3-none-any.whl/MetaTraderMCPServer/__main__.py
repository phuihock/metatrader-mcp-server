#!/usr/bin/env python
# -*- coding: utf-8 -*-

def main():
    """
    Main entry point for the MetaTrader MCP server application.
    """
    print("Hello World! 🌎")
    print("MetaTrader MCP Server starting...")

if __name__ == "__main__":
    main()
